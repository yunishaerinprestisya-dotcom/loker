package com.lowongankerja.ui.dashboard

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.lowongankerja.data.model.Job

class DashboardViewModel : ViewModel() {
    private val _jobs = MutableLiveData<List<Job>>()
    val jobs: LiveData<List<Job>> = _jobs

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    fun loadJobs(token: String) {
        // Mengisi data dummy simulasi
        val dummyJobs = listOf(
            Job(1, "Android Developer", "PT Teknologi Nusantara", "Jakarta", "Rp 8.000.000 - Rp 12.000.000"),
            Job(2, "UI/UX Designer", "Studio Digital Kreatif", "Bandung", "Rp 6.000.000 - Rp 9.000.000"),
            Job(3, "Backend Engineer", "Global Data Utama", "Surabaya", "Rp 10.000.000 - Rp 15.000.000"),
            Job(4, "Data Analyst", "Fintech Indonesia", "Remote", "Rp 7.500.000 - Rp 11.000.000")
        )
        _jobs.value = dummyJobs
    }
}